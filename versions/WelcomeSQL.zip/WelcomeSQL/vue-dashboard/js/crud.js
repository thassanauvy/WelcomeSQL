const API_BASE = 'http://127.0.0.1:5000/api';

document.addEventListener('DOMContentLoaded', () => {
  document.getElementById('addUserBtn').addEventListener('click', addUserFromForm);
  fetchData();
});

async function fetchData() {
  try {
    const res = await fetch(`${API_BASE}/users`);
    const json = await res.json();
    populateTable(json.data);
  } catch (err) {
    console.error('Fetch error:', err);
  }
}

function populateTable(data) {
  const headerRow = document.getElementById('tableHeader');
  const body = document.getElementById('tableBody');
  headerRow.innerHTML = '';
  body.innerHTML = '';

  if (data.length === 0) {
    const tr = document.createElement('tr');
    const td = document.createElement('td');
    td.textContent = 'No data available';
    td.colSpan = 100;
    tr.appendChild(td);
    body.appendChild(tr);
    return;
  }

  const headers = Object.keys(data[0]);
  headers.push('Actions');
  headers.forEach(h => {
    const th = document.createElement('th');
    th.textContent = h;
    headerRow.appendChild(th);
  });

  data.forEach(user => {
    const tr = document.createElement('tr');
    headers.forEach(h => {
      if (h === 'Actions') {
        const td = document.createElement('td');

        const editBtn = document.createElement('button');
        editBtn.textContent = 'Edit';
        editBtn.onclick = () => {
          const newFirst = prompt('New First Name:', user.firstName);
          const newLast = prompt('New Last Name:', user.lastName);
          const newUsername = prompt('New Username:', user.username || '');
          const newEmail = prompt('New Email:', user.email || '');
          const newPasskey = prompt('New Passkey:', '');

          if (newFirst && newLast) {
            updateUser(user.userID, {
              firstName: newFirst,
              lastName: newLast,
              username: newUsername,
              email: newEmail,
              passkey: newPasskey
            });
          }
        };

        const deleteBtn = document.createElement('button');
        deleteBtn.textContent = 'Delete';
        deleteBtn.onclick = () => {
          if (confirm(`Delete user ${user.firstName}?`)) {
            deleteUser(user.userID);
          }
        };

        td.appendChild(editBtn);
        td.appendChild(deleteBtn);
        tr.appendChild(td);
      } else {
        const td = document.createElement('td');
        td.textContent = user[h] || '';
        tr.appendChild(td);
      }
    });
    body.appendChild(tr);
  });
}

async function createUser(userData) {
  try {
    const res = await fetch(`${API_BASE}/user`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(userData)
    });
    const json = await res.json();
    alert(json.message);
    fetchData();
  } catch (err) {
    console.error('Create error:', err);
  }
}

async function updateUser(userID, userData) {
  try {
    const res = await fetch(`${API_BASE}/user/${userID}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(userData)
    });
    const json = await res.json();
    alert(json.message);
    fetchData();
  } catch (err) {
    console.error('Update error:', err);
  }
}

async function deleteUser(userID) {
  try {
    const res = await fetch(`${API_BASE}/user/${userID}`, {
      method: 'DELETE'
    });
    const json = await res.json();
    alert(json.message);
    fetchData();
  } catch (err) {
    console.error('Delete error:', err);
  }
}

function addUserFromForm() {
  const userData = {
    userID: parseInt(document.getElementById('userID').value),
    firstName: document.getElementById('firstName').value,
    lastName: document.getElementById('lastName').value,
    username: document.getElementById('username').value,
    email: document.getElementById('email').value,
    passkey: document.getElementById('passkey').value
  };
  createUser(userData);
}
