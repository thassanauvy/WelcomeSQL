# WelcomeSQL 

- Basic SQL stuff (SELECT, WHERE, JOIN etc.)
- Adding, changing and deleting data 
- Setting up your own tables from scratch
- Joining tables together
- Calculating cool stuff with your data

Find me on GitHub: [@thassanauvy](https://github.com/thassanauvy)
